# Hackerspace 1 - VGU Cypher CTF for beginner

- Write-up by [Qân](https://github.com/CallMeQan)
- Thuộc phần **Web Exploitation**

## Đánh giá

- Nhấn vào link thì dẫn ta tới website trang login, ta liền nghĩ tới ngay kỹ thuật [SQL Injection](https://portswigger.net/web-security/sql-injection)

## Solution

- Nhập vào phần username là `admin' #`
- Password cái gì cũng được

=> **Cái flag to đùng trước mặt**
